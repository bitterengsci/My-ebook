## `3d point-to-point ICP Optimization` (Octave)

While in this folder, run the test program with:

     octave ICP_3D_test.m
