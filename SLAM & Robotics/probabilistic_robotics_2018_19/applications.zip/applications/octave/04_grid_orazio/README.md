## grid-orazio (Octave)
While in this folder, launch the program with:
 
     octave grid_orazio.m maps/map.txt
     
Orazio can be moved with the keyboard controls (W, A, S, D).

