function map = getMap(filename) 

  #generate/load our map
  map = load(filename);

endfunction

