## `3d point-to-point alignment with Linear Relaxation` (Octave)

While in this folder, run the test program with:

     octave ICPTest.m
