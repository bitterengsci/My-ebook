## `ICP on a Manifold vs ICP without Manifold` (Octave)
Run the following script for a comparative analysis of the 3D ICP variants:

    octave-cli icp_3D_nomanifold_vs_manifold.m

For more detailed states (e.g. inlier counts due to the robust kernel in LS):

    octave-cli icp_3D_stats.m

