Differential Drive calibration

dataset format:
- every lines contains the following quantities:
  [ tick_left, tick_right, x, y, theta]

the quantities are RELATIVE
